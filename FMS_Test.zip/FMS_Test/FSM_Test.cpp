﻿// * 2014032111 신덕유 FSM_Test 2020-04-16

#include <iostream>
using namespace std;

#define SAFE_DELETE( p )			{ if( p ){ delete p;		p = NULL; } }	// 객체 삭제

enum	SCENE_TYPE	/* 씬 타입 */ { SN_TITLE = 1, SN_FIELD, SN_MENU, SN_BATTLE, SN_END, SN_ERROR };

//  ==============================================================================================
class Scene
{
public:
	Scene()	{	};
	virtual ~Scene() {	};

	SCENE_TYPE NextScene()
	{
		int next;

		cout << endl << endl;
		cout << "  <Next> " << endl;
		cout << " 1 | Title" << endl;
		cout << " 2 | Field"<< endl;
		cout << " 3 | Menu" << endl;
		cout << " 4 | Battle" << endl;
		cout << " 5 | End" << endl;
		cout << " → ";

		cin >> next;
		cout << "-----------(처리중)-----------" << endl;

		return (SCENE_TYPE)next;
	};
};

class Title : public Scene
{
public:
	Title()
	{
		cout << "<Title Scene 활성화>" << endl;
	};
	virtual ~Title() {	};
};

class Field : public Scene
{
public:
	Field()
	{
		cout << "<Field Scene 활성화>" << endl;
	};
	virtual ~Field() {	};
};

class Menu : public Scene
{
public:
	Menu()
	{
		cout << "<Menu Scene 활성화>" << endl;
	};
	virtual ~Menu() {	};
};

class Battle : public Scene
{
public:
	Battle()
	{
		cout << "<Battle Scene 활성화>" << endl;
	};
	virtual ~Battle() {	};
};

class End : public Scene
{
public:
	End()
	{
		cout << "<End Scene 활성화>" << endl;
	};
	virtual ~End() {	};
};

class Error : public Scene
{
public:
	Error()
	{
		cout << "<Error Scene 활성화>" << endl;
	};
	virtual ~Error() {	};
};


// Main ==============================================================================================
int main()
{
	Scene* scene = new Scene();
	SCENE_TYPE type = SN_TITLE;	// 기본은 타이틀
	bool end_flag = false;

	while(true)
	{
		switch (type)
		{
		case SN_TITLE:
			scene = new Title();
			cout << " 게임에 오신 것을 환영합니다. " << endl;
			break;

		case SN_FIELD:
			scene = new Field();
			cout << " 필드에 도착했습니다. " << endl;
			break;

		case SN_MENU:
			scene = new Menu();
			cout << " 메뉴를 확인합니다. " << endl; 
			break;

		case SN_BATTLE:
			scene = new Battle();
			cout << " 전투를 시작합니다. " << endl;
			break;

		case SN_END:
			scene = new End();
			end_flag = true;
			break;

		default:
			scene = new Error();
			cout << " 에러 발생! 다시 입력하세요! " << endl;
			break;
		}
		if (end_flag) break;

		type = scene->NextScene(); // 특정 작업으로 대체될 수 있음
		SAFE_DELETE(scene);		// Scene 초기화
	}

	SAFE_DELETE(scene);		// Scene 초기화
	return 0;
}
